import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormControl } from '@angular/forms';
import { RegisterPageForm } from './form/register.page.form';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {

  registerForm!: RegisterPageForm;

  constructor(private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.createForm();
  }

  register() {
    this.registerForm.getForm().markAllAsTouched();
    if (this.registerForm.getForm().valid){
      this.router.navigate(['login']);
    }
  }

  private createForm() {
    this.registerForm = new RegisterPageForm(this.formBuilder);
  }
  // Getter umum untuk mendapatkan FormControl berdasarkan nama field
  getFieldControl(fieldName: string): FormControl {
    return this.registerForm.getForm().get(fieldName) as FormControl;
  }
}
