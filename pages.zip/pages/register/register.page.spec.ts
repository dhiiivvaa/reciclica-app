import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RegisterPage } from './register.page';
import { Router } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { RegisterPageModule } from './register.module';

describe('RegisterPage', () => {
  let component: RegisterPage;
  let fixture: ComponentFixture<RegisterPage>;
  let router: Router;
  let page: HTMLElement;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [RegisterPage],
      imports: [
        IonicModule.forRoot(),
        AppRoutingModule,
        ReactiveFormsModule,
        RegisterPageModule
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(RegisterPage);
    router = TestBed.inject(Router);  // Perbaiki pengambilan Router
    component = fixture.componentInstance;
    page = fixture.debugElement.nativeElement;
  }));

  it('should create register form on page init', () => {
    fixture.detectChanges();
    expect(component.registerForm).not.toBeUndefined();
  });

  it('should go to login page on register if form is valid', () => {
    fixture.detectChanges();
    spyOn(router, 'navigate');

    // Isi nilai untuk setiap kontrol dalam formulir
    component.registerForm.getForm().patchValue({
      name: 'anyName',
      email: 'any@email.com',
      password: 'anyPassword',
      repeatPassword: 'anyPassword',
      phone: 'anyPhone',
      address: {
        street: 'any street',
        number: 'any number',
        complement: 'any complement',
        neighborhood: 'any neighborhood',
        zipCode: 'any zip code',
        city: 'any city',
        state: 'any state'
      }
    });

    component.register();  // Panggil metode register untuk menavigasi

    expect(router.navigate).toHaveBeenCalledWith(['login']);
  });

  it('should not navigate if form is invalid', () => {
    fixture.detectChanges();
    spyOn(router, 'navigate');

    page.querySelector('ion-button')?.click();

    expect(router.navigate).toHaveBeenCalledTimes(0);
  });
});
